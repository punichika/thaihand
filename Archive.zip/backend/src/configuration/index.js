module.exports = {
      JWT_SECRET: 'codeworkrauthentication',
      oauth: {
        facebook: {
          clientID: '898321800522977',
          clientSecret: 'a51c2c351ba143c0540df2f4cc88dbc6',
        },
      },
};
  