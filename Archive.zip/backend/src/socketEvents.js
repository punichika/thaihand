exports = module.exports = function (io) {
    io.on('connection', (socket) => {
        console.log('a user connected');


        // On conversation entry, join broadcast channel
        socket.on('enter conversation', (conversation) => {
            socket.join(conversation);
            console.log('joined ' + conversation);
        });

        socket.on('leave conversation', (conversation) => {
            socket.leave(conversation);
            console.log('left ' + conversation);
        });

        socket.on('new message', (conversation) => {
            io.sockets.emit('refresh messages', conversation);
        });

        socket.on('new notification', (conversations) => {
            io.sockets.emit('refresh conversation', conversations);
        });

        socket.on('create message', data => {
            io.sockets.emit('refresh conversation', data);
        });

        socket.on('disconnect', () => {
            console.log('user disconnected');
        });
    });
};