import express from 'express';
import fileUpload from 'express-fileupload';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import router from './router';

const socketEvents = require('./socketEvents');

const app = express();
const PORT = process.env.PORT || 5000;

mongoose.connect(
	'mongodb://localhost/thaihand',
	{ useNewUrlParser: true }
);
app.use(function(req, res, next) {  
	res.header('Access-Control-Allow-Origin', req.headers.origin);
	res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	next();
});  

const db = mongoose.connection;
db.once('open', () => console.log('mongodb is connected')).on('error', err =>
	console.error(err)
);

app.use(fileUpload({
    useTempFiles : true,
    tempFileDir : '/tmp/'
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


app.use('/', router);

let server =app.listen(PORT, () => {
	console.log('server connected at ' + PORT);
});


const io = require('socket.io').listen(server);
socketEvents(io);