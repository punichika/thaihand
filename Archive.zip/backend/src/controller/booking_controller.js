import Booking from '../models/Booking';



export const createBooking = (req, res) => {
	const { name,date,time} = req.body

	

		const newBooking = new Booking({ name: name, date: date, time: time});

		newBooking
			.save()
			.then(() => Category.find())
			.then(val => res.json(val));
		console.log('success')



};

export const getBooking = (req, res) => {

	Booking.find().then(val => res.json(val)

	);
	console.log("get category finish")



};
 
