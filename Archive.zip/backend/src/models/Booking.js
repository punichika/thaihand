import mongoose, { Schema } from 'mongoose';

const BookingSchema = new Schema(
	{
		user: String,
		Date: String,
		time: String
	},
	{
		timestamps: true
	}
);

export default mongoose.model('Booking', BookingSchema);
