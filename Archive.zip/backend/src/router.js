import { Router } from 'express';
const passport = require('passport');

import {
	createBooking ,getBooking
} from './controller/booking_controller';




const router = new Router();



router.post('/createbooking', createBooking)

router.get('/fetchbooking',getBooking)






	

export default router;
