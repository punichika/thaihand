declare module 'console' {
    export = typeof import("console");
}