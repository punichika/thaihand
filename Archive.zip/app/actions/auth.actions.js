

import { CREATE_BOOKING,
		FETCH_BOOKING
	
} from './types.actions';
import { createBooking} from '../config/api';




export const getBooking = () => async dispatch => {
	dispatch({ type: LOADING, payload: true });

	const data = await fetchBooking();
	dispatch({ type: FETCH_BOOKING, payload: data });
};


export const Booking = ({ name,date,time}) => async dispatch => {
	const data = await createBooking({name,date,time})

	dispatch({ type: CREATE_BOOKING, payload: data });
};

