export const blueColor = '#009CD5';
export const whiteColor = '#fff';
