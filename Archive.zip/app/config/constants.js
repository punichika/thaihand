

const PORT = '5000';
//const PATH = 'user';


export const SERVER_URL = `http://localhost:${PORT}`

export const IMAGE_URL = 'https://cdn.pixabay.com/photo/2016/11/29/04/19/beach-1867285_960_720.jpg';
