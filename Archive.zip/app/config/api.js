import { SERVER_URL } from './constants';

const serverUrl = SERVER_URL;

const config = (url, method, body) =>
	fetch(url, {
		method,
		cache: 'no-cache',
		headers: {
			'Content-Type': 'application/json'
		},
		body: JSON.stringify(body)
	}).then(response => response.json());




export const fetchBooking = () => config(serverUrl+'/fetchbooking', 'GET')

export const createBooking = ({name,date,time}) => config(serverUrl+'/createbooking', 'POST' ,{name,date,time})

