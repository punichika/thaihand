import {
	CREATE_BOOKING,
	FETCH_BOOKING
} from '../actions/types.actions';

const INITIAL_STATE = {
	
	data:[]
};

export default (state = INITIAL_STATE, actions) => {
	switch (actions.type) {
		
		case FETCH_BOOKING:
			return { ...state, data: actions.payload, loading: false };
		
		case CREATE_BOOKING:
			return { ...state };
		
		default:
			return { ...state };
	}
};
