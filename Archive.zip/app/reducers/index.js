import { combineReducers } from 'redux';
import authReducers from './auth.reducer';
import lastActionReducer from './lastaction.reducer';

export default combineReducers({
	auth: authReducers,
	lastAction:lastActionReducer
});
