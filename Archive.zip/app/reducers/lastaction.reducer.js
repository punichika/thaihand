

const INITIAL_STATE = {
	email: '',
	password: '',
	user: '',
	users: []
};

export default function lastAction(state = null, action) {
	return action;
  }