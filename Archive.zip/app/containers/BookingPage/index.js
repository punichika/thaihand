/*
 * FeaturePage
 *
 * List all the features
 */
import React , { Component } from 'react';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { Booking,getBooking} from '../../actions/auth.actions';

import Table from '../../components/Table';
import Modal from '../../components/Modal';
import '../../global-styles.css';
import '../../responsive-styles.css';
import 'bootstrap/dist/css/bootstrap.css';


class BookingPage extends Component {
  
    constructor(props) {
      super(props);
      this.state={
        show:false,
        name:"",
        date:"",
        time:"",
        data:[]

      }
    } 
    componentDidMount(){
      //this.props.actions.getBooking()

    }
  
  
  showModal = () => {
    this.setState({ show: true });
  };

  hideModal = () => {
    this.setState({ show: false });
  };
  submit =() =>{

    this.props.actions.Booking({name,date,time}).then(function(){
      this.prop.actions.getBooking()
    })

  }
  render() {
  
    const name =this.state.name
    const date = this.state.date
    const time = this.state.time
 
    console.log(this.props.data)
    console.log(loading)
  return (
    <div>
      <Helmet>
        <title>Feature Page</title>
        <meta
          name="description"
          content="Feature page of React.js Boilerplate application"
        />
      </Helmet>
      <div style={{ paddingTop: '100px', paddingBottom: '100px' }} >
        <div class="row">
          <div class="col-md-3">

          </div>
          <div class="col-md-6">
            <Table data={this.state.data}></Table>

            <button onClick={this.showModal} class="btn btn-primary">
              Booking
            </button>
            <Modal show={this.state.show} handleClose={this.hideModal}>
              <input type="text" placeholder="name" onChangeText={text => this.setState({name: text})}></input>
              <input type="text" placeholder="date" onChangeText={text => this.setState({date: text})}></input>
              <input type="text" placeholder="time" onChangeText={text => this.setState({time: text})}></input>
              <button class="btn btn-primary" onClick={this.submit} >Submit</button>
            </Modal>
          </div>
          <div class="col-md-3">

          </div>

        </div>
      </div>
    </div>
  );
  }
}

function mapStateToProps(state) {
  const { data,loading} = state.auth;
  return {data,loading}
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ Booking,getBooking}, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(BookingPage);



 