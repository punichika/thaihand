/*
 * FeaturePage
 *
 * List all the features
 */
import React , { Component } from 'react';
import { Helmet } from 'react-helmet';
import { FormattedMessage } from 'react-intl';

import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

import { Booking,getBooking} from '../../actions/auth.actions';

import Table from '../../components/Table';
import Modal from '../../components/Modal';
import '../../global-styles.css';
import '../../responsive-styles.css';
import 'bootstrap/dist/css/bootstrap.css';


class FeaturePage extends Component {
  
    constructor(props) {
      super(props);
      this.state={
        show:false,
        name:"",
        date:"",
        time:"",
        data:[]

      }
    } 
    
    componentDidMount(){
      //this.props.actions.getBooking()

    }
  
  
  showModal = () => {
    this.setState({ show: true });
  };

  hideModal = () => {
    this.setState({ show: false });
  };
 
  render() {
  
    const name =this.state.name
    const date = this.state.date
    const time = this.state.time
    
 
   
  return (
    <div>
      <Helmet>
        <title>Feature Page</title>
        <meta
          name="description"
          content="Feature page of React.js Boilerplate application"
        />
      </Helmet>
      <div style={{ paddingTop: '100px', paddingBottom: '100px' }} >
        <div class="row">
          <div class="col-md-3">

          </div>
          <div class="col-md-6" className="center">
              <input type="text" placeholder="name" onChange={text => this.setState({name: text})}></input><br></br>
              <input type="text" placeholder="date" onChange={text => this.setState({date: text})}></input><br></br>
              <input type="text" placeholder="time" onChange={text => this.setState({time: text})}></input><br></br>
              <button class="btn btn-primary" onClick={ () => this.props.actions.Booking({name,date,time})} >Submit</button> 
          </div>
          <div class="col-md-3">

          </div>

        </div>
      </div>
    </div>
  );
  }
}

function mapStateToProps(state) {
 
  return state
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators({ Booking,getBooking}, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(FeaturePage);



 