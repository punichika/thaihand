import React from 'react';
import { FormattedMessage } from 'react-intl';

import A from 'components/A';
import LocaleToggle from 'containers/LocaleToggle';
import Wrapper from './Wrapper';
import messages from './messages';
const bg ={
  backgroundColor: '#414162'
}

function Footer() {
  return (
    <Wrapper style={bg}>
      <div >
        <h1>Footer</h1>

      </div>
    </Wrapper>
  );
}

export default Footer;
