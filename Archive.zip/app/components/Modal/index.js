import React from 'react';
import PropTypes from 'prop-types';

import Item from './Item';
import Wrapper from './Wrapper';
import '../../global-styles.css';
import 'bootstrap/dist/css/bootstrap.css';

export default class Modal extends React.Component {
  render() {
    if (!this.props.show) {
      return null;
    }
    return( 
      
      <div>
      {this.props.children}
      </div>
     
    );
  }
}


