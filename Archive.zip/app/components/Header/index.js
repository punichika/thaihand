import React from 'react';
import { FormattedMessage } from 'react-intl';

import A from './A';
import Img from './Img';
import NavBar from './NavBar';
import HeaderLink from './HeaderLink';
import Banner from './banner.jpg';
import messages from './messages';
import '../../global-styles.css';

const grad ={
  backgroundImage:`linear-gradient(15deg, #52527C 0%, #B48CB6 100%)`,
  paddingTop:'20px',
  paddingBottom:'20px'

}





function Header() {
  return (
    <div>
      <nav  style={grad}>
        <span class="navbar-brand mb-0 h1\" style={{color:'white'}}>Navbar</span>
      </nav>
   
    </div>
    
  );
}


export default Header;
