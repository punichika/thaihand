import React from 'react';
import PropTypes from 'prop-types';

import Item from './Item';
import Wrapper from './Wrapper';
import '../../global-styles.css';
import 'bootstrap/dist/css/bootstrap.css';

function Table(props) {
  return (
    <table id="customers">
      <tr>
        <th>name</th>
        <th>date</th>
        <th>time</th>
      </tr>
  
    </table>
  );
}

Table.propTypes = {
  item: PropTypes.any,
};

export default Table;
